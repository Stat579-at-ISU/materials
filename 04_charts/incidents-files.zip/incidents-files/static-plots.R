library(tidyverse)
library(lubridate)
library(ggmap)

logs <- read.csv("log.csv", stringsAsFactors = FALSE)
football <- read.csv("football.csv", stringsAsFactors = FALSE)
football <- football %>% mutate(
  Date = ymd(paste(Year, Month, Day)),
  Game = c("Home", "Away")[Home+1]
)
ames <- readRDS("ames.rds")


byday <- logs %>% 
  mutate(
    Date = ymd_hms(Date),
    Date = as.Date(Date)  # no time
    ) %>%
  complete(Date = full_seq(Date, 1)) %>%
  group_by(Date) %>%
  summarize(
    n = sum(!is.na(Case.Number))
  )

### temporal
byday %>%
  ggplot(aes(x = Date, y = n)) +
  geom_vline(aes(xintercept = Date, colour=Game), data = football) +
  geom_point() +
  ylab("Number of incidences") +
  facet_wrap(~year(Date), scales="free_x") +
  scale_colour_manual(values=c("Darkred", "Gold"))


### spatial

base <- logs %>% filter(!is.na(Alcohol)) %>%
  ggplot(aes(x = longitude, y = latitude, group=Alcohol)) 

ggmap(ames, base_layer = base) +
  stat_density2d(aes(fill = ..level.., alpha = ..level..),
                 bins = 20, geom = "polygon") +
  facet_wrap(~Alcohol, labeller = "label_both") +
  scale_fill_gradient2("Hotspots\n(estimated frequency)", low = "white", mid = "orange", high = "darkred", midpoint = 10) +
  scale_alpha("Hotspots", range = c(.2, .75), guide = FALSE) +
  ggthemes::theme_map() +
  theme(legend.position = "bottom")   
