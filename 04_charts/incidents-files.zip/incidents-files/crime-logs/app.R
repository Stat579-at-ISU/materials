#
# This is a Shiny web application. You can run the application by clicking
# the 'Run App' button above.
#
# Find out more about building applications with Shiny here:
#
#    http://shiny.rstudio.com/
#

library(tidyverse)
library(lubridate)
library(ggmap)

logs <- read.csv("../log.csv", stringsAsFactors = FALSE)
logs <- logs %>% mutate(
    Classification = factor(Classification),
    Classification = reorder(Classification, Classification, function(x) -length(x)))
football <- read.csv("../football.csv", stringsAsFactors = FALSE)
football <- football %>% mutate(
    Date = ymd(paste(Year, Month, Day)),
    Game = c("Away", "Home")[Home+1]
)
ames <- readRDS("../ames.rds")


byday <- logs %>% 
    mutate(
        Date = ymd_hms(Date),
        Date = as.Date(Date)  # no time
    ) %>%
    complete(Date = full_seq(Date, 1)) %>%
    group_by(Date) %>%
    summarize(
        n = sum(!is.na(Case.Number))
    )

library(shiny)

# Define UI for application that draws a histogram
ui <- fluidPage(

    # Application title
    titlePanel("ISU Crime Logs"),

    # Sidebar with a slider input for number of bins 
    sidebarLayout(
        sidebarPanel(
            sliderInput("daterange", "Dates", min = as.Date("2012-01-01"),
                        value = c(as.Date("2012-01-01"), as.Date("2019-03-01")),
                        max = as.Date("2019-03-01")),
            checkboxGroupInput("classification", label="Classification",
                               choices = levels(logs$Classification))
        ),

        # Show a plot of the generated distribution
        mainPanel(
           plotOutput("distPlot"),
           plotOutput("mapPlot")
        )
    )
)

# Define server logic required to draw a histogram
server <- function(input, output) {

    output$distPlot <- renderPlot({
        byday %>%
          filter(Date >= input$daterange[1], Date <= input$daterange[2]) %>%
            ggplot(aes(x = Date, y = n)) +
            geom_vline(aes(xintercept = Date, colour=Game), data = football) +
            geom_point() +
            ylab("Number of incidences") +
            facet_wrap(~year(Date), scales="free_x") +
            scale_colour_manual(values=c("Gold", "Darkred"))
    })
    output$mapPlot <- renderPlot({
        sub <- logs %>% filter(!is.na(Alcohol)) %>%
            filter(Date >= input$daterange[1], Date <= input$daterange[2]) 
        if (length(input$classification) != 0) {
        sub <- sub %>%
            filter(Classification %in% input$classification) 
        }
        
        base <- sub %>%
                ggplot(aes(x = longitude, y = latitude)) 
        
        ggmap(ames, base_layer = base) +
            stat_density2d(aes(fill = ..level.., alpha = ..level..),
                           bins = 20, geom = "polygon") +
        #    facet_wrap(~Alcohol, labeller = "label_both") +
            scale_fill_gradient2("Hotspots\n(estimated frequency)", low = "white", mid = "orange", high = "darkred", midpoint = 10) +
            scale_alpha("Hotspots", range = c(.2, .75), guide = FALSE) +
            ggthemes::theme_map() +
            theme(legend.position = "bottom")   
    })
}

# Run the application 
shinyApp(ui = ui, server = server)
